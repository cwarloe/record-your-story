import type { TimelineData, TimelineEntry } from "./types";

export interface InitOptions {
  defaultView?: "list" | "timeline";
  persistKey?: string; // localStorage key
}

export function initRecordYourStory(container: HTMLElement, data: TimelineData, options: InitOptions = {}): void {
  const persistKey = options.persistKey ?? "rys:view";
  const initial = (localStorage.getItem(persistKey) as "list"|"timeline") ?? (options.defaultView ?? "timeline");
  const state = { view: initial };
  const years = groupByYear(data.entries ?? []);
  container.classList.add("rys-container");

  // toolbar
  const bar = document.createElement("div");
  bar.className = "rys-toolbar";
  const btnList = mkButton("List");
  const btnTimeline = mkButton("Timeline");
  bar.append(btnList, btnTimeline);
  container.append(bar);

  function render() {
    btnList.setAttribute("aria-pressed", String(state.view === "list"));
    btnTimeline.setAttribute("aria-pressed", String(state.view === "timeline"));
    try { localStorage.setItem(persistKey, state.view); } catch {}

    // clear existing content (except toolbar)
    container.querySelectorAll(".rys-content").forEach(n => n.remove());
    if (state.view === "list") renderList(container, years);
    else renderTimeline(container, years);
  }

  btnList.addEventListener("click", () => { state.view = "list"; render(); });
  btnTimeline.addEventListener("click", () => { state.view = "timeline"; render(); });

  render();
}

function mkButton(label: string): HTMLButtonElement {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = label;
  return b;
}

function groupByYear(entries: TimelineEntry[]): Array<{year: string, items: TimelineEntry[]}> {
  const by = new Map<string, TimelineEntry[]>();
  entries
    .slice()
    .sort((a,b) => (a.dateISO || "").localeCompare(b.dateISO || ""))
    .forEach(e => {
      const y = (e.dateISO || "").slice(0,4) || "Unknown";
      if (!by.has(y)) by.set(y, []);
      by.get(y)!.push(e);
    });
  return Array.from(by.entries())
    .sort((a,b) => a[0].localeCompare(b[0]))
    .map(([year, items]) => ({year, items}));
}

function renderList(root: HTMLElement, years: Array<{year: string, items: TimelineEntry[]}>): void {
  const wrap = document.createElement("div");
  wrap.className = "rys-content rys-list";
  years.forEach(({year, items}) => {
    const h = document.createElement("h2");
    h.className = "rys-year";
    h.textContent = year;
    wrap.appendChild(h);
    items.forEach(it => wrap.appendChild(card(it, "rys-card")));
  });
  root.appendChild(wrap);
}

function renderTimeline(root: HTMLElement, years: Array<{year: string, items: TimelineEntry[]}>): void {
  const wrap = document.createElement("div");
  wrap.className = "rys-content rys-timeline";
  years.forEach(({year, items}, idx) => {
    const h = document.createElement("h2");
    h.className = "rys-year";
    h.textContent = year;
    wrap.appendChild(h);

    items.forEach((it, i) => {
      const row = document.createElement("div");
      row.className = "rys-tl-row";
      const dot = document.createElement("div");
      dot.className = "rys-tl-dot";
      row.appendChild(dot);
      const side = ((i + idx) % 2 === 0) ? "left" : "right";
      row.appendChild(card(it, "rys-tl-card " + side));
      wrap.appendChild(row);
    });
  });
  root.appendChild(wrap);
}

function card(it: TimelineEntry, cls: string): HTMLElement {
  const c = document.createElement("article");
  c.className = cls;
  const t = document.createElement("h3");
  t.textContent = it.title || "(Untitled)";
  const p = document.createElement("p");
  p.textContent = it.description || "";
  const d = document.createElement("div");
  d.style.fontSize = "0.9rem";
  d.style.opacity = "0.7";
  d.textContent = fmtDate(it.dateISO);
  c.append(t, d, p);
  return c;
}

function fmtDate(iso?: string): string {
  if (!iso) return "";
  try {
    const dt = new Date(iso);
    return dt.toLocaleDateString(undefined, {year:"numeric", month:"short", day:"2-digit"});
  } catch {
    return iso ?? "";
  }
}

export default initRecordYourStory;
