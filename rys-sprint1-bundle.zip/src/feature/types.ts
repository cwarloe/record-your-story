export interface TimelineEntry {
  id: string;
  title: string;
  description?: string;
  dateISO: string; // YYYY-MM-DD
  tags?: string[];
}
export interface TimelineData { entries: TimelineEntry[]; }
export type TimelineView = "list" | "timeline";
